﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animals
{
    class Animal
    {
        public String Name;
        public int Weight;

        public Animal(String Name, int Weight)
        {
            this.Name = Name;
            this.Weight = Weight;
        }

    }
}
